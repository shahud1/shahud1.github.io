
import pandas as pd
import csv
import glob
from tqdm import tqdm
import datetime
import subprocess
import os

# reservations = pd.read_csv('car1.csv')
# df = reservations
# car1heat = df[df.enginestate == "START"]


# reservations = pd.read_csv('car2.csv')
# df = reservations
# car2heat = df[df.enginestate == "START"]


# print(car1heat)
# car1heat.to_csv('car1heat.csv', header=True)
# print(car2heat)
# car2heat.to_csv('car2heat.csv', header=True)

#csv2geojson --lat latitude --lon longitude /Users/enki/Desktop/Finaldemo/car2heat.csv > /Users/enki/Desktop/Finaldemo/car2heat.geojson

car1heatmap = pd.DataFrame(columns=['lat', 'long', 'enginestate','logtime','day'])
car2heatmap = pd.DataFrame(columns=['lat', 'long', 'enginestate','logtime','day'])



df = pd.read_csv('car1heat.csv')
df2 = pd.read_csv('car2heat.csv')


for i in tqdm(range(len(df))):
    #print(df.logtime[i])
    try:
        time = datetime.datetime.strptime(df.logtime[i], "%Y-%m-%dT%H:%M:%S.%f%z")
    except:
        time = datetime.datetime.strptime(df.logtime[i], "%Y-%m-%dT%H:%M:%S%z")
    hour = time.hour
    car1heatmap = car1heatmap.append({'lat':df.latitude[i],'long':df.longitude[i],'enginestate':df.enginestate[i],'logtime':hour,'day':time.strftime("%A")}, ignore_index=True)

print(car1heatmap)
car1heatmap.to_csv('car1heatmap.csv', header=True)


df = df2

for i in tqdm(range(len(df))):
    #print(df.logtime[i])
    try:
        time = datetime.datetime.strptime(df.logtime[i], "%Y-%m-%dT%H:%M:%S.%f%z")
    except:
        time = datetime.datetime.strptime(df.logtime[i], "%Y-%m-%dT%H:%M:%S%z")
    hour = time.hour
    car2heatmap = car2heatmap.append({'lat':df.latitude[i],'long':df.longitude[i],'enginestate':df.enginestate[i],'logtime':hour,'day':time.strftime("%A")}, ignore_index=True)

print(car2heatmap)
car2heatmap.to_csv('car2heatmap.csv', header=True)