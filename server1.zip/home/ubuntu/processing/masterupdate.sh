#!/bin/bash 

echo Updating...

cd /Users/enki/Desktop/Finaldemo/


mongoexport --uri="mongodb://tusmartcity:tu2018@log.haupcar.com/tusmartcity" --collection=interval --query '{"logtime":{"$gte": "2019-11-08T00:00:00+07:00"}}' --type=csv --out=/Users/enki/Desktop/Finaldemo/raw.csv --fields _id,vehicleid,reservationno,logtime,latitude,longitude,speed,heading,hdop,fuel,charge,km,doorlockstate,enginestate


python3 /Users/enki/Desktop/Finaldemo/currentlocation.py

echo Converting Car1

csv2geojson --lat lat --lon long /Users/enki/Desktop/Finaldemo/car1latest.csv > /Users/enki/Desktop/shahud1.github.io/car1latest.geojson

echo Converting Car2

csv2geojson --lat lat --lon long /Users/enki/Desktop/Finaldemo/car2latest.csv > /Users/enki/Desktop/shahud1.github.io/car2latest.geojson

python3 /Users/enki/Desktop/Finaldemo/todaydata.py

csv2geojson --lat lat --lon long --line true /Users/enki/Desktop/Finaldemo/car1today.csv > /Users/enki/Desktop/shahud1.github.io/car1today.geojson

csv2geojson --lat lat --lon long --line true /Users/enki/Desktop/Finaldemo/car2today.csv > /Users/enki/Desktop/shahud1.github.io/car2today.geojson


cd ~/Desktop/shahud1.github.io
git pull
git branch -u origin/master
git add --all
git commit -m "Initial commit"
git push -u origin master

echo Finished update

read -p "Press enter to continue"


